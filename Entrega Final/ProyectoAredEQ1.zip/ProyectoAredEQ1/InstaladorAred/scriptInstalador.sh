#!/bin/bash
dirscript=$(readlink -f $0)
dirbase=`dirname $dirscript`

su -l $2 -c 'rm -R /home/'$2'/.ared 2> /dev/null'
su -l $2 -c 'mkdir /home/'$2'/.ared 2> /dev/null'

echo "Bienvenido al instalador del sistema AredEspacio"
su -l $2 -c 'mkdir '$1'/AredEspacioEQ1 2> /dev/null'
su -l $2 -c 'cp -r '$dirbase'/configAred/ '$1"/AredEspacioEQ1"
su -l $2 -c 'cp -r '$dirbase'/configAred/userPhoto/ /home/'$2"/.ared"
su -l $2 -c 'cp -r '$dirbase'/configAred/fonts/ /home/'$2"/.ared"
su -l $2 -c 'cp -r '$dirbase'/configAred/imagenes/ /home/'$2"/.ared"

var=$1"/AredEspacioEQ1"

su -l $2 -c 'echo "#!/bin/bash
java -jar "'$var'"/configAred/ared-1.0-SNAPSHOT.jar" >> '$var'"/"AredEspacioEQ1.sh'
echo "Ingresa tu contraseña de MySql:"
mysql -u $3 -p < $var/configAred/AredDBSchema.sql

echo "[Desktop Entry]
Name=Ared Espacio
Comment=Sistema para la Administración de la Escuela de Danza AredEspacio
Exec="$var"/AredEspacioEQ1.sh
Icon="$var"/configAred/nombreAred.ico
Terminal=false
Type=Application
" >> /usr/share/applications/aredespacio.desktop

chmod 755 $var"/"AredEspacioEQ1.sh
chmod 755 $var
